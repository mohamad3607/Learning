using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraPrinting.Preview;

namespace WindowsApplication1 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            XtraReport1 xrep = new XtraReport1();
            xrep.CreateDocument();
            xrep.PrintingSystem.PreviewFormEx.Load += new EventHandler(PreviewFormEx_Load); // adding a handler to the Load event of the preview form

            xrep.ShowPreviewDialog();



        }

        void PreviewFormEx_Load(object sender, EventArgs e) {
            PrintPreviewFormEx frm = (PrintPreviewFormEx)sender;
           frm.PrintingSystem.ExecCommand(DevExpress.XtraPrinting.PrintingSystemCommand.Scale, new object[] {1});
            frm.Location = new Point(0, 0);
            frm.Size = new Size(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);



        }
    }
}