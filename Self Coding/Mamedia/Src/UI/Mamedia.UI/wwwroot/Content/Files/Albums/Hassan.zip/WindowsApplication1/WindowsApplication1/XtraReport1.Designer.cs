namespace WindowsApplication1 {
    partial class XtraReport1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.xrPivotGrid1 = new DevExpress.XtraReports.UI.XRPivotGrid();
            this.nwindDataSet1 = new WindowsApplication1.nwindDataSet();
            this.order_DetailsTableAdapter = new WindowsApplication1.nwindDataSetTableAdapters.Order_DetailsTableAdapter();
            this.fieldOrderID = new DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField();
            this.fieldProductID = new DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField();
            this.fieldUnitPrice = new DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField();
            this.fieldQuantity = new DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField();
            this.fieldDiscount = new DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField();
            ((System.ComponentModel.ISupportInitialize)(this.nwindDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrPivotGrid1});
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // PageHeader
            // 
            this.PageHeader.Height = 30;
            this.PageHeader.Name = "PageHeader";
            this.PageHeader.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.PageHeader.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // PageFooter
            // 
            this.PageFooter.Height = 30;
            this.PageFooter.Name = "PageFooter";
            this.PageFooter.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.PageFooter.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrPivotGrid1
            // 
            this.xrPivotGrid1.DataAdapter = this.order_DetailsTableAdapter;
            this.xrPivotGrid1.DataMember = "Order Details";
            this.xrPivotGrid1.DataSource = this.nwindDataSet1;
            this.xrPivotGrid1.Fields.AddRange(new DevExpress.XtraPivotGrid.PivotGridField[] {
            this.fieldOrderID,
            this.fieldProductID,
            this.fieldUnitPrice,
            this.fieldQuantity,
            this.fieldDiscount});
            this.xrPivotGrid1.Location = new System.Drawing.Point(0, 0);
            this.xrPivotGrid1.Name = "xrPivotGrid1";
            this.xrPivotGrid1.Size = new System.Drawing.Size(217, 50);
            // 
            // nwindDataSet1
            // 
            this.nwindDataSet1.DataSetName = "nwindDataSet";
            this.nwindDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // order_DetailsTableAdapter
            // 
            this.order_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // fieldOrderID
            // 
            this.fieldOrderID.Area = DevExpress.XtraPivotGrid.PivotArea.RowArea;
            this.fieldOrderID.AreaIndex = 0;
            this.fieldOrderID.Caption = "OrderID";
            this.fieldOrderID.FieldName = "OrderID";
            this.fieldOrderID.Name = "fieldOrderID";
            this.fieldOrderID.Width = 500;
            // 
            // fieldProductID
            // 
            this.fieldProductID.Area = DevExpress.XtraPivotGrid.PivotArea.FilterArea;
            this.fieldProductID.AreaIndex = 0;
            this.fieldProductID.Caption = "ProductID";
            this.fieldProductID.FieldName = "ProductID";
            this.fieldProductID.Name = "fieldProductID";
            // 
            // fieldUnitPrice
            // 
            this.fieldUnitPrice.Area = DevExpress.XtraPivotGrid.PivotArea.FilterArea;
            this.fieldUnitPrice.AreaIndex = 1;
            this.fieldUnitPrice.Caption = "UnitPrice";
            this.fieldUnitPrice.FieldName = "UnitPrice";
            this.fieldUnitPrice.Name = "fieldUnitPrice";
            // 
            // fieldQuantity
            // 
            this.fieldQuantity.Area = DevExpress.XtraPivotGrid.PivotArea.DataArea;
            this.fieldQuantity.AreaIndex = 0;
            this.fieldQuantity.Caption = "Quantity";
            this.fieldQuantity.FieldName = "Quantity";
            this.fieldQuantity.Name = "fieldQuantity";
            // 
            // fieldDiscount
            // 
            this.fieldDiscount.Area = DevExpress.XtraPivotGrid.PivotArea.DataArea;
            this.fieldDiscount.AreaIndex = 1;
            this.fieldDiscount.Caption = "Discount";
            this.fieldDiscount.FieldName = "Discount";
            this.fieldDiscount.Name = "fieldDiscount";
            // 
            // XtraReport1
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.PageHeader,
            this.PageFooter});
            this.Version = "8.3";
            this.VerticalContentSplitting = DevExpress.XtraPrinting.VerticalContentSplitting.Smart;
            ((System.ComponentModel.ISupportInitialize)(this.nwindDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRPivotGrid xrPivotGrid1;
        private WindowsApplication1.nwindDataSetTableAdapters.Order_DetailsTableAdapter order_DetailsTableAdapter;
        private nwindDataSet nwindDataSet1;
        private DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField fieldOrderID;
        private DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField fieldProductID;
        private DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField fieldUnitPrice;
        private DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField fieldQuantity;
        private DevExpress.XtraReports.UI.PivotGrid.XRPivotGridField fieldDiscount;
    }
}
